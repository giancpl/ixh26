Use fingerprinto-pitch.pdf for the six-screen timed pitch. The technical PDF also includes eleven Q&A pages; do not show those in the three-minute slot. Keep assets/ alongside the PDFs for the page-5 external demo link. If blocked, pre-open assets/demo-pitch.mp4. Supplied recording is silent at 1.5x / 29.41 seconds. Total pitch budget: 180 seconds including demo. Human-review/AI disclosure must be completed by the team.

Additional original: assets/video_2026-11-21_11-11-30.mp4 (35.05 seconds), optional Q&A recording; do not play both clips in the timed pitch.
