Compile main.tex with pdfLaTeX for the six-screen, three-minute pitch. Compile extended.tex for the same six screens plus eleven Q&A backup pages (17 total). Do not show backups during the timed pitch. The supplied demo recording is an external MP4, silent at 1.5x / 29.41 seconds: keep assets/demo-pitch.mp4 beside downloaded PDFs. Some readers block launch actions: pre-open the player. AI-use/team-human-review disclosure is explicitly incomplete [TBD].

Additional original: assets/video_2026-11-21_11-11-30.mp4 (35.05 seconds), optional Q&A recording; do not play both clips in the timed pitch.
